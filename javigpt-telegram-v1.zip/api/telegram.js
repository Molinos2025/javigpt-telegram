const TELEGRAM_API = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
const OPENAI_API = "https://api.openai.com/v1/responses";

async function telegram(method, body) {
  const r = await fetch(`${TELEGRAM_API}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body)
  });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

async function askOpenAI(message) {
  const r = await fetch(OPENAI_API, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "authorization": `Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      input: [
        {
          role: "system",
          content: "Eres JaviGPT Personal, el asistente privado de Javi. Responde en español, de forma clara, útil y directa. No inventes información. Todavía no tienes memoria persistente ni búsqueda web."
        },
        { role: "user", content: message }
      ]
    })
  });
  if (!r.ok) throw new Error(await r.text());
  const data = await r.json();
  return data.output_text || "No he podido generar una respuesta.";
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(200).json({ ok: true, service: "JaviGPT Telegram" });

  try {
    const update = req.body;
    const message = update?.message;
    if (!message?.chat?.id) return res.status(200).json({ ok: true });

    const text = message.text?.trim();
    if (!text) {
      await telegram("sendMessage", {
        chat_id: message.chat.id,
        text: "De momento puedo trabajar con mensajes de texto. Próximamente añadiremos voz e imágenes."
      });
      return res.status(200).json({ ok: true });
    }

    if (text === "/start") {
      await telegram("sendMessage", {
        chat_id: message.chat.id,
        text: "👋 Hola Javi. Soy JaviGPT Personal. Ya estoy conectado. Escríbeme cualquier cosa."
      });
      return res.status(200).json({ ok: true });
    }

    if (text === "/help") {
      await telegram("sendMessage", {
        chat_id: message.chat.id,
        text: "🤖 JaviGPT Personal\n\nEscríbeme normalmente y te responderé con IA.\n\n/start — iniciar\n/help — ayuda\n/nuevochat — nueva conversación\n/memoria — memoria"
      });
      return res.status(200).json({ ok: true });
    }

    if (text === "/nuevochat") {
      await telegram("sendMessage", {
        chat_id: message.chat.id,
        text: "🆕 Conversación nueva. La memoria persistente la añadiremos en la siguiente versión."
      });
      return res.status(200).json({ ok: true });
    }

    if (text === "/memoria") {
      await telegram("sendMessage", {
        chat_id: message.chat.id,
        text: "🧠 La memoria personal todavía no está activada. La añadiremos después de comprobar que el bot básico funciona."
      });
      return res.status(200).json({ ok: true });
    }

    await telegram("sendChatAction", { chat_id: message.chat.id, action: "typing" });
    const answer = await askOpenAI(text);

    for (let i = 0; i < answer.length; i += 3900) {
      await telegram("sendMessage", {
        chat_id: message.chat.id,
        text: answer.slice(i, i + 3900)
      });
    }

    return res.status(200).json({ ok: true });
  } catch (error) {
    console.error(error);
    return res.status(200).json({ ok: false });
  }
}
