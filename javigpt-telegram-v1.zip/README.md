# JaviGPT Personal — Telegram

Bot privado de Telegram conectado a la OpenAI Responses API y preparado para Vercel.

Variables de entorno:
- TELEGRAM_BOT_TOKEN
- OPENAI_API_KEY
- OPENAI_MODEL (opcional; por defecto gpt-5.6-luna)

Después del despliegue en Vercel, abre una vez /api/setup para registrar el webhook de Telegram.
